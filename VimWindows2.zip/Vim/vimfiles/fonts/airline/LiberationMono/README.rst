Literation Mono Powerline
=========================

:Font creator: Steve Mattesen
:Version: 2.00.1
:Source: https://fedorahosted.org/liberation-fonts/
:License: SIL OPEN FONT LICENSE Version 1.1
:Patched by: `Carl X. Su <https://github.com/bcbcarl>`_

The Liberation Fonts is font collection which aims to provide document
layout compatibility as usage of Times New Roman, Arial, Courier New.

Literation Mono Powerline is derived from The Liberation Fonts for
Powerline users. The Powerline symbols is being made by Kim
Silkebækken. The patch work is being undertaken by Carl X. Su.

Both the final font Truetype/OpenType files and the design files used
to produce the font family are distributed under an open licence and
you are expressly encouraged to experiment, modify, share and improve.